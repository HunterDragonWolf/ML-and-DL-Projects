mkdir -p ~/.streamlit/

echo "\
[server]\n\
headless = true\n\
enableCORS=false\n\
port = SPORT\n\
" > ~/.streamlit/config.toml